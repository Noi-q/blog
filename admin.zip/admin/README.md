# admin

## 前言

- blog的后端程序,基于Go的Gin框架实现

### 依赖

- Gin `github.com/gin-gonic/gin`
- viper `github.com/spf13/viper`
- gorm
  - `gorm.io/gorm`
  - `gorm.io/driver/mysql`
- jwt `github.com/dgrijalva/jwt-go`